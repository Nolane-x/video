# Public Release Notice — H2 Squire Studio

The author has expressly withdrawn the former personal-only / no-sharing restriction for this release and authorizes public hosting of this Squire source package in the GitHub repository Nolane-x/video, together with execution, modification, and video production workflows for that repository.

This notice applies to the package as published in the repository above. Third-party dependencies and assets remain subject to their own upstream licenses and notices. This release does not claim to relicense third-party components.
