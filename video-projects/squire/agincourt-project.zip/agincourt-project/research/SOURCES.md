# Research source ledger — Agincourt 1415

| Claim | Source | Caution |
|---|---|---|
| Longbow range and proportion of archers | English Heritage — https://www.english-heritage.org.uk/learn/story-of-england/medieval/war/ | Maximum range is not guaranteed armour penetration. |
| Armour weight and mobility | The Metropolitan Museum of Art — https://www.metmuseum.org/pt/essays/arms-and-armor-common-misconceptions-and-frequently-asked-questions | Well-fitted articulated plate armour does not immobilise its wearer. |
| Army number reconstruction | University of Southampton — https://www.southampton.ac.uk/news/2016/05/the-truth-about-agincourt.page | Anne Curry's estimate is contested and should not be presented as a census. |
| Stakes and cavalry tactics | Historical Association — https://www.history.org.uk/publications/categories/301/resource/8654/the-archers-stake-and-the-battle-of-agincourt | Contextual interpretation of the stake system. |
| Campaign chronology | Cambridge University Press — https://www.cambridge.org/core/books/abs/agincourt-campaign-of-1415/during-the-campaign/4CE34B0E066E5BE65538EAC0B43417A1 | Scholarly campaign reconstruction. |
| Battle overview / deployment | College of Arms — https://www.college-of-arms.gov.uk/news-grants/news/item/119-the-battle-of-agincourt | Compare institutional overview with scholarship. |

Contemporary accounts can be partisan. Exact totals, casualty counts and battlefield location remain debated. Do not claim all arrows penetrated plate or that knights could not stand because of armour. Shakespeare's Saint Crispin speech is literary drama, not a verbatim battlefield transcript.
