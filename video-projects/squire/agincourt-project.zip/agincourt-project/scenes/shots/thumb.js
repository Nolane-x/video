import { thumb } from '/packs/squire/pack.js';

thumb({
  bg: 'mud', time: 'storm', blur: 10,
  back: [{ preset: 'frenchKnight', rows: 4, cols: 14, x0: 0.25, x1: 1, yFront: 0.9, yBack: 0.62, hFront: 0.24, hBack: 0.12, advance: 0.003 }],
  hero: { preset: 'frenchKnight', x: 0.68, y: 0.56, R: 0.25, face: 'scared', pose: 'cower', visor: 'down', shield: null },
  symbols: [{ kind: 'arrow', x: 0.18, y: 0.63, to: [0.4, 0.72], r: 0.17 }],
  title: ['NO ROOM'], tx: 0.28, ty: 0.13, tsize: 0.23,
});
