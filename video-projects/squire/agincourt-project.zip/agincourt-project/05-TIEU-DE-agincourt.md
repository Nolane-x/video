# YouTube publishing package

## Title candidates
1. Why French Knights Couldn't Move at Agincourt
2. The Battle That Turned an Army Into a Crowd
3. Why Agincourt Became a Death Trap for the French
4. The Real Reason France Lost at Agincourt
5. How Mud, Stakes, and Longbows Broke a French Army
6. The Myth About Medieval Armour That Agincourt Exposes
7. When More Soldiers Made an Army Weaker
8. Agincourt: The Army That Ran Out of Room

## Thumbnail
One trapped French knight in close-up, visor down, wet field and compressed blue ranks behind him. One red arrow toward the narrowing gap. White outlined text: NO ROOM.

## Description
On 25 October 1415, a French army entered the muddy corridor near Agincourt expecting to overwhelm Henry V's exhausted English force. The familiar explanation says longbows simply destroyed knights in heavy armour. The evidence points to a more complicated failure: difficult ground, constrained deployment, defensive stakes, archery from the flanks, and a formation that became too crowded to fight.

This animated history follows the campaign from Harfleur to the battlefield, tests the myth about plate armour, and separates evidence from legend. Army numbers remain debated; the estimate associated with historian Anne Curry is presented as one reconstruction, not a final count.

## Tags
Agincourt, Battle of Agincourt, Henry V, Hundred Years War, medieval warfare, medieval history, French knights, English longbow, longbowmen, plate armour, military history, battle tactics, 1415, history animation, animated history
