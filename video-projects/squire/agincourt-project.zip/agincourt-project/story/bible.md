# AGINCOURT 1415 — Visual Bible

## Story promise
A first-person historical battle explainer correcting the myth that plate armour made knights immobile. The central visual idea is a shrinking amount of usable space in a battlefield corridor.

## Visual grammar
- Code-drawn 2D Squire animation; no photo humans or AI stills.
- Simple symbolic characters with period armour, horses, heraldry and weapons.
- Rich staged sets: Normandy harbour, Harfleur walls, muddy road, river crossing, woodland corridor, English stake line, medieval tents.
- Layered armies in background and foreground; motivated camera movement; varied wide, medium, close and overhead compositions.
- Long-form 16:9, captions off; use only short in-world labels.

## Character continuity
- Main French viewpoint: frenchKnight / knight15; French blue #315b8c and gold #d6ad56; visor down in battle.
- English archers: englishArcher; English red #a93f37.
- English men-at-arms: knight15 with red accent.
- Henry V: henry preset; avoid any photoreal likeness.
- Do not mix French blue with English red.

## Choreography
- Horse charge: anticipation, gallop, stakes/arrows interrupt, turn/fall/recovery.
- Infantry: advance into a narrowing corridor; front ranks slow, rear ranks continue, then formation compresses.
- Show readable contact between sword, shield, horse and ground.
- Armour articulates at shoulders, elbows, hips and knees; show mobility before crowd pressure removes usable space.
- Mud is communicated through planted boots, splashes, stumbling and falling bodies, not a cartoon pit.

## Story structure
1. Cold open: a French man-at-arms loses room to move.
2. Rewind: Henry's 1415 campaign and Harfleur.
3. The march north and the attempt to block Calais.
4. Longbow, stakes and French deployment.
5. Armour myth: a well-fitted harness remains mobile.
6. Battle: cavalry disruption, infantry pressure and formation collapse.
7. System explanation: terrain, mud, stakes, flank archery and congestion.
8. Historiography: army-size estimates remain disputed.
9. Final reversal: the army ran out of room.

## Audio
- Music arc: suspense, medieval, suspense, war, somber, victory.
- Narration clearly in front; SFX only when visually motivated.
- Use mud steps, rain, horse hooves, war horn, drums, arrow volley, sword clash, shield bash and armour clank.
- Deliberate music drop before final line.
