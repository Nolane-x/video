# 03 — Art direction and visual plan

- Format: longform 16:9, 1920x1080, 24 fps.
- Narration: English, VieNeu v3 Turbo Adam, captions off.
- Story length: about 9.5 minutes at normal documentary pace.

## Visual chapters
1. 0–30s cold open in mud: boots, visor, shoulders, rear ranks pressing; compress the battlefield space.
2. Normandy and Harfleur: landing, fortified port, siege engines, camps, disease and surrender.
3. March north: parchment map with Harfleur, Somme, Calais and Agincourt; road, boots, food and exhaustion.
4. English weapons: longbow insert, arrowhead, wooden stakes, archer line facing cavalry.
5. Armour myth: plate armour bends, kneels and rises; close joints, hands, visor and weight.
6. Battlefield geometry: overhead plan of a narrow corridor between woodland, wet earth and army blocks.
7. Battle: cavalry turns, infantry advances, front ranks halt, rear ranks compress, flank archers attack.
8. System explanation: terrain, mud, stakes, archery and congestion shown separately then together.
9. Numbers and legend: board marked ESTIMATES DISPUTED; manuscript and Shakespeare context; quiet final battlefield.

## Template rotation
- scene: environment with a focal character and layered formations.
- close: reactions, visor, hands, boots and articulation.
- army: English archers and French men-at-arms.
- map: Harfleur → Somme → Calais → Agincourt.
- top / plan: formation movement and narrowing space.
- item: bow, arrowhead, stake, helmet, sword, shield.
- board: army estimates and armour weight with caveats.
- split: myth versus evidence.
- frame: manuscript / legacy sequence.

## Palette
- French: #315b8c and #d6ad56.
- English: #a93f37 and #f3eee2.
- Mud: #72553c; soil: #8e7754; storm sky: slate grey.
- No neon glow and no generic gradient-only scenes.

## Historical guardrails
- Battle date: 25 October 1415.
- Do not say all arrows penetrated plate armour.
- Plate harness commonly around 20–25 kg and remains articulated and mobile.
- Army totals remain disputed; Anne Curry's archival estimate is one reconstruction, not a definitive count.
- Shakespeare's Saint Crispin speech is literary, not a verbatim transcript of Henry's words.
- Do not claim a precise battlefield location as settled.

## Sources
- English Heritage: https://www.english-heritage.org.uk/learn/story-of-england/medieval/war/
- The Met: https://www.metmuseum.org/pt/essays/arms-and-armor-common-misconceptions-and-frequently-asked-questions
- University of Southampton: https://www.southampton.ac.uk/news/2016/05/the-truth-about-agincourt.page
- Historical Association: https://www.history.org.uk/publications/categories/301/resource/8654/the-archers-stake-and-the-battle-of-agincourt
- Cambridge University Press: https://www.cambridge.org/core/books/abs/agincourt-campaign-of-1415/during-the-campaign/4CE34B0E066E5BE65538EAC0B43417A1
- College of Arms: https://www.college-of-arms.gov.uk/news-grants/news/item/119-the-battle-of-agincourt
