#!/usr/bin/env python3
import argparse, json, re
from pathlib import Path

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p, x): Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def contains(t, *terms): return any(x in t for x in terms)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', required=True)
    a = ap.parse_args()
    root = Path(a.project)
    story_path = root / 'story' / 'shots.json'
    data = read(story_path)
    shots = data.get('shots', [])
    if not shots: raise SystemExit('No draft shots found')
    duration = float(data.get('duration', 0))
    prev = []
    for i, shot in enumerate(shots):
        text = shot.get('line', '')
        t = text.casefold()
        phase = float(shot.get('start', 0)) / max(duration, 1)
        # The visual environment changes with the story chapter.
        if float(shot.get('start', 0)) < 25: bg, light = 'mud', 'storm'
        elif contains(t, 'harfleur', 'siege', 'wall', 'port', 'normandy'): bg, light = 'castle', 'day'
        elif contains(t, 'sommes', 'calais', 'river', 'map', 'march north'): bg, light = 'field', 'golden'
        elif contains(t, 'mud', 'rain', 'sink', 'ploughed', 'wet'): bg, light = 'mud', 'storm'
        elif phase > .83: bg, light = 'field', 'dawn'
        else: bg, light = 'field', 'day'
        english = contains(t, 'english archer', 'longbow', 'archer', 'english line', 'english soldier', 'henry')
        hero = 'englishArcher' if contains(t, 'longbow', 'archer', 'bow', 'stake', 'arrow') else ('henry' if contains(t, 'henry') else ('knight15' if english else 'frenchKnight'))
        side = '#a93f37' if english else '#315b8c'
        if contains(t, 'sommes', 'calais', 'harfleur', 'normandy', 'agincourt', 'river'): tpl = 'map'
        elif contains(t, 'twelve thousand', 'eight thousand', 'five to one', 'estimates', 'twenty to twenty-five', 'kilograms', 'weight'): tpl = 'board'
        elif contains(t, 'formation', 'ranks', 'narrow', 'crowd', 'corridor', 'flanks', 'compressed', 'space begins', 'same corridor', 'rear ranks'): tpl = 'top' if i % 2 == 0 else 'plan'
        elif contains(t, 'bow', 'arrow', 'stake', 'helmet', 'sword', 'shield', 'armour', 'armor', 'plate', 'boots', 'horse', 'weapon'): tpl = 'item' if i % 3 == 0 else 'close'
        elif contains(t, 'myth', 'misconception', 'not magic', 'the answer is a system'): tpl = 'split'
        elif contains(t, 'army', 'archers', 'men-at-arms', 'french force', 'english force', 'troops'): tpl = 'army'
        elif contains(t, 'account', 'shakespeare', 'legend', 'chronicle', 'records'): tpl = 'frame'
        else: tpl = 'scene'
        if len(prev) >= 2 and prev[-1] == tpl and prev[-2] == tpl:
            tpl = 'scene' if tpl in ('close', 'item') else 'close'
        face = 'determined'
        if contains(t, 'sink', 'mud', 'no room', 'crowd', 'crush', 'fall', 'trapped', 'pressure', 'cannot', 'barely'): face = 'scared'
        elif contains(t, 'sick', 'hungry', 'tired', 'exhausting', 'feet hurt', 'disease'): face = 'tired'
        elif contains(t, 'myth', 'misconception', 'wrong', 'not magic'): face = 'confused'
        pose = 'stand'
        if contains(t, 'march', 'stepping ashore', 'move forward', 'advance', 'follow the road'): pose = 'march'
        elif contains(t, 'fall', 'stumble', 'sink', 'knees bend', 'crouch'): pose = 'crouch'
        elif contains(t, 'fight', 'swing', 'charge', 'attack', 'closes with'): pose = 'fight'
        args = {'bg': bg, 'time': light, 'move': 'in' if i % 3 == 0 else ('left' if i % 3 == 1 else 'still')}
        if light == 'storm': args['fx'] = [{'kind': 'rain'}]
        if tpl == 'map':
            args = {'view': [-1.0, 48.7, 3.6, 51.5],
                    'places': [{'text':'Harfleur','lon':0.20,'lat':49.50,'at':'Harfleur'},
                               {'text':'Somme','lon':1.95,'lat':49.90,'at':'Somme'},
                               {'text':'Calais','lon':1.85,'lat':50.95,'at':'Calais'},
                               {'text':'Agincourt','lon':2.14,'lat':50.46,'at':'Agincourt'}],
                    'routes': [{'pts': [[0.20,49.50],[1.0,49.7],[1.95,49.90],[1.85,50.95]],'at':'march','dur':1.6}]}
        elif tpl == 'board':
            args = {'title':'AGINCOURT — ESTIMATES', 'bars':[{'label':'ENGLISH','v':0.72,'at':'English'}, {'label':'FRENCH','v':1.0,'at':'French'}], 'mult':{'text':'ESTIMATES DISPUTED','x':0.5,'y':0.77,'at':'disputed'}}
        elif tpl == 'top':
            args = {'ground':{'color':'#917b58','grass':True},
                    'blocks':[{'x':0.15,'y':0.50,'w':0.20,'h':0.40,'rows':8,'cols':8,'side':'red','cell':0.021},
                              {'x':0.63,'y':0.49,'w':0.18,'h':0.38,'rows':7,'cols':12 if contains(t,'crowd','pressure','compressed') else 8,'side':'blue','cell':0.021}],
                    'arrows':[{'from':[0.72,0.50],'to':[0.47,0.50],'at':'advance','w':7,'color':'#c9473a'}]}
        elif tpl == 'plan':
            args = {'paper':'parchment','blocks':[{'x':0.22,'y':0.30,'w':0.14,'h':0.38,'side':'red','cols':6,'rows':10},
                                                    {'x':0.64,'y':0.30,'w':0.14,'h':0.38,'side':'blue','cols':6,'rows':10}],
                    'zones':[{'x':0.50,'y':0.52,'w':0.18,'h':0.55,'color':'#8b6a49','lw':9,'at':'narrow','dur':1.0}],
                    'arrows':[{'from':[0.70,0.51],'to':[0.51,0.51],'at':'advance','w':6,'color':'#c9473a'}]}
        elif tpl == 'army':
            args = {'preset':hero,'rows':4,'cols':14,'bg':bg,'time':light,'face':face,'move':'right' if i % 2 else 'in',
                    'flags':[{'col':0.24,'row':0.76,'kind':'vexillum','color':side}]}
        elif tpl == 'close':
            args = {'preset':hero,'face':face,'pose':pose,'x':0.52,'R':0.235,'bg':bg,'time':light,'visor':'down' if hero == 'frenchKnight' else 'none','move':'in'}
        elif tpl == 'item':
            kind = 'bow' if contains(t,'bow','archer') else ('helmet' if contains(t,'helmet','armour','armor','plate','visor') else ('stake' if 'stake' in t else ('sword' if contains(t,'sword','weapon','fight') else 'shield')))
            args = {'bg':bg,'time':light,'thing':{'kind':kind,'s':0.54,'x':0.44,'y':0.54,'anim':'pop'},'props':[],'move':'in'}
            if 'arrow' in t: args['props'].append({'kind':'arrow','x':0.72,'y':0.46,'s':0.32,'at':'arrow','anim':'float'})
            if 'stake' in t: args['props'].append({'kind':'stake','x':0.72,'y':0.55,'s':0.42,'at':'stake','anim':'pop','rot':0.28})
        elif tpl == 'split':
            args = {'left':{'color':'#6e4b43','people':[{'preset':'frenchKnight','x':0.25,'h':0.61,'face':'worried','pose':'stand'}]},
                    'right':{'color':'#315b8c','people':[{'preset':'frenchKnight','x':0.75,'h':0.61,'face':'determined','pose':'stand'}]},
                    'labels':[{'text':'THE MYTH','x':0.25,'y':0.13,'at':'myth','size':68},{'text':'THE REALITY','x':0.75,'y':0.13,'at':'reality','size':64}]}
        elif tpl == 'frame':
            args = {'bg':'wood','people':[{'preset':'henry','x':0.55,'h':0.61,'face':'determined','pose':'present'}], 'props':[{'kind':'scroll','x':0.25,'y':0.66,'s':0.34}]}
        else:
            args = {'bg':bg,'time':light,'people':[{'preset':hero,'x':0.52,'y':0.92,'h':0.60,'face':face,'pose':pose,'tabardColor':side,
                                                    'visor':'down' if hero == 'frenchKnight' else 'none',
                                                    'weapon':'sword' if hero == 'frenchKnight' else ('bow' if hero == 'englishArcher' else None)}],
                    'back':[{'preset':'frenchKnight' if hero == 'englishArcher' else 'englishArcher','rows':3,'cols':13,'x0':0.05,'x1':0.95,'yFront':0.86,'yBack':0.69,'hFront':0.18,'hBack':0.10}],
                    'move':'in' if i % 3 == 0 else 'still'}
            if light == 'storm': args['fx'] = [{'kind':'rain'}]
            if contains(t,'horse','cavalry'):
                args['people'][0]['horse'] = {'color':'grey','gait':'gallop'}
                shot['sfx'] = [{'name':'horse_snort','at':0.2,'gain':-7},{'name':'horse_neigh','at':0.5,'gain':-7}]
            if contains(t,'stake','stakes'): args['props'] = [{'kind':'stake','x':0.72,'y':0.84,'s':0.34,'rot':0.24}]
        cues = []
        if contains(t,'arrow','longbow','archer'): cues.append({'name':'arrow_volley','at':0.35,'gain':-6})
        if contains(t,'sword','fight','combat','men-at-arms'): cues.append({'name':'sword_clash','at':0.6,'gain':-7})
        if contains(t,'mud','boots','march','sink'): cues.append({'name':'mud_step','at':0.25,'gain':-8})
        if cues: shot['sfx'] = cues[:2]
        shot['tpl'] = tpl
        shot['args'] = args
        shot['in'] = {'type':'fade' if i == 0 or (i % 14 == 0) else 'cut'}
        shot['notes'] = 'DROP' if i == len(shots)-1 else ''
        if i < 3: shot['args'].setdefault('signs',[{'text':'YOU','x':0.5,'y':0.14,'at':0.3,'size':42}])
        prev.append(tpl)
    data['title'] = 'Agincourt 1415 — The Army That Ran Out of Room'
    data['music'] = [
        {'start':0,'end':round(duration*.08,3),'bed':'suspense','gainDb':0},
        {'start':round(duration*.08,3),'end':round(duration*.28,3),'bed':'medieval','gainDb':0},
        {'start':round(duration*.28,3),'end':round(duration*.43,3),'bed':'suspense','gainDb':0},
        {'start':round(duration*.43,3),'end':round(duration*.73,3),'bed':'war','gainDb':0},
        {'start':round(duration*.73,3),'end':round(duration*.95,3),'bed':'somber','gainDb':0},
        {'start':round(duration*.95,3),'end':duration,'bed':'victory','gainDb':0}]
    write(story_path, data)
    config_path = root / 'config.json'
    config = read(config_path)
    config.update({'captions':False,'pack':'squire','aspect':'16:9','resolution':'1080p','fps':24,'loudness':-14})
    config['music'] = {'enabled':True,'gainDb':-10}
    config['sfx'] = {'enabled':True,'gainDb':-4}
    write(config_path, config)
    counts = {}
    for s in shots: counts[s['tpl']] = counts.get(s['tpl'],0)+1
    print('Authored',len(shots),'shots;',round(duration,2),'seconds;',counts)

if __name__ == '__main__': main()
