# Agincourt 1415 — Squire longform production

Production project for the first longform historical military animation genre in Nolane-x/video.

- 01-SCRIPT-agincourt.md: full English narration.
- voice-job.json: validated VoiceStudio request using VieNeu v3 Turbo Adam.
- transcript.txt: source transcript.
- story/bible.md: continuity and art direction.
- 03-HINH-agincourt.md: chapter-by-chapter visual plan.
- 05-TIEU-DE-agincourt.md: titles, thumbnail and YouTube description.
- research/SOURCES.md: fact/source ledger.
- tools/author_story.py: deterministic line-to-shot director.
- scenes/shots/thumb.js: code-drawn thumbnail.

The final MP4 is a candidate until full-length visual and perceptual audio QA has been completed.
