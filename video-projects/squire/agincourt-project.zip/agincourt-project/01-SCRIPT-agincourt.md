Imagine you are a French man-at-arms, and the ground is trying to keep you. Your boots sink. The man behind you does not stop. You lift your sword, but there is barely room to move it. Ahead, the English line is still standing. You are not trapped inside your armour. You are trapped inside a crowd.

You have trained for years. Your family expects you to be brave. You brought a horse, a sword, a helmet, and a suit of plate. You were told the French army was stronger. Yet outside a small village in northern France, all that strength is becoming useless.

This is Agincourt, the twenty-fifth of October, fourteen fifteen. It became one of England's most famous victories. The familiar story says a tiny English army destroyed an enormous French host with longbows. But armour did not make a knight helpless. The battlefield made an army too crowded to fight.

To understand why, leave the mud. Return to the summer of fourteen fifteen. The Hundred Years' War has lasted for generations. Henry the Fifth has taken the English throne, and he wants more than a raid. He wants to make his claim to the French crown impossible to ignore.

You are now an English soldier stepping ashore in Normandy. In August, Henry's army moves toward Harfleur, a fortified port. The town refuses to surrender. The English build siege positions, dig, guard the approaches, and bring their engines close to the walls.

The siege lasts for weeks. The English live in wet camps, under strain, while disease moves through the ranks. Harfleur surrenders on the twenty-second of September. It is a victory, but not a clean one. The army is tired, sick, and smaller than when it landed.

Henry has a choice. He can return home, or march north toward Calais, an English-held port, and show the campaign is not over. He chooses the march. You shoulder your equipment and follow the road north.

The French do not need one dramatic charge. They only need to block the road and make the English run out of food. Crossings of the River Somme are guarded. The English search for a way across, lose days, and keep moving. French forces shadow them.

The march is exhausting. You carry weapons, food, clothing, and armour. Your feet hurt. Men fall ill; some suffer from dysentery. The army is hungry, and every day the distance to Calais shrinks while the number of men fit to fight shrinks too.

By the twenty-fourth of October, the armies can see one another near Agincourt. The French wait for reinforcements. Henry's men are weakened, but waiting is dangerous too. The French can let hunger do the work. Henry needs to force a battle.

Keep one rule in mind. An army is not powerful because it has the most people. It is powerful when those people can act together. At Agincourt, that difference will decide what happens to men who have trained all their lives to fight.

Look at the English line. A very large share of Henry's army consists of archers. English Heritage describes them as roughly five-sixths of the force. They carry longbows made for war. A powerful bow can send an arrow well over two hundred metres, though range alone does not guarantee a hit or a penetration.

The longbow is dangerous, but not magic. An arrow striking a well-made plate at a poor angle may glance away. At closer range, a narrow point can threaten gaps, joints, horses, and less protected areas. The English advantage comes from many archers working as part of a formation.

You are an English archer. At your feet are sharpened wooden stakes, angled toward the French approach. They are not a wall. They make a direct charge harder to control. A horse sees points where a clear path should be. Its rider must slow, turn, or risk the animal.

The French plan includes mounted men-at-arms who should disrupt the archers. Other troops will press the English centre. But the French must deploy across a narrow space, with woods constraining the sides and wet ground underfoot.

Now return to your French harness. It is not a barrel of iron. A field suit of plate armour usually weighs around twenty to twenty-five kilograms, with its weight distributed across the body. The plates overlap and the joints are articulated. You can bend, walk, climb, and get up after falling.

The Metropolitan Museum of Art calls the idea that plate armour made a knight immobile a misconception. Well-fitted armour allows movement. The harder question is what happens when a mobile man must cross deep mud, shoulder to shoulder, while another rank keeps pushing from behind.

The field near Agincourt has been disturbed by ploughing and rain. The soil is wet. A corridor between wooded areas limits how widely an army can deploy. Historians still debate the battlefield's exact location, but constrained ground and difficult footing feature in most accounts.

For hours, the armies face each other. The English are hungry and weakened by disease. The French have more troops, but wait for additional men. The pause is not peaceful. It is a test of nerve, supply, and time.

Henry moves first. The English advance, bringing their archers closer. They pull up their stakes and plant them again. It is risky, but it brings the French within range and forces their commanders to respond on ground the English have chosen.

You are a French cavalryman. Your horse moves forward. Ahead, archers stand behind angled stakes. Arrows fall. The ground is rough and the approach is crowded. Some horses turn or lose control. Others are hit. The charge fails to open a clear road.

You are ordered forward on foot with the men-at-arms. You lower your visor. The world becomes a strip of mud, steel, banners, and bodies. You see the English line ahead. You cannot see how many men are pressing toward your back.

At first, the French attack still has force. The front ranks close with the English men-at-arms. The English line bends. This is not target practice from a safe distance. There is brutal hand-to-hand combat in the centre, and the outcome is still uncertain.

Then the space begins to disappear. Men in the first ranks slow down. Some stumble. Some fall. The ranks behind keep advancing because they cannot see what is happening. Shoulders collide. Shields and weapons catch. A fallen man becomes an obstacle for everyone behind him.

The English archers move around the edges of the melee and attack from the sides. The French centre cannot spread out. A sword needs room to swing. A spear needs space to point. The more bodies enter the same corridor, the less each man can use his strength.

A contemporary English account describes men falling onto the dead under the pressure of the French mass. It was written by the winning side and must be read with care. But a French account also describes the vanguard as so tightly packed that men several ranks back could scarcely use their swords.

You understand the trap. Your armour is not pinning your arms to your sides. The man beside you is. The fallen horse is. The mud is. The man behind you is still moving forward. You breathe inside your helmet and discover there is no room to use your sword.

The pressure makes every mistake spread. A man trips, and the next has nowhere to go. A horse falls, and bodies behind it must climb or turn. Commanders cannot easily send fresh men around the sides. The formation is too deep and the corridor too narrow. The army has become a crowd.

Henry's centre is under serious pressure. The English king is not watching from a distant hill. Accounts place him in the fighting. His brother Humphrey, Duke of Gloucester, is wounded and protected by the king's men. The English line holds long enough for the French attack to lose its shape.

As leaders fall or are captured, units lose direction. Some men keep fighting. Others try to escape the crush. The archers continue attacking from the sides, where mobility matters more than piercing a breastplate. The English men-at-arms press forward. The French no longer fight as one force.

So what defeated the French? Was it the longbow? It disrupted the approach, threatened horses, and punished crowded formations. Was it the mud? It increased fatigue and made falling dangerous. Was it armour? No. Armour protected its wearer, but it could not create space.

The answer is a system of problems. Narrow ground restricted deployment. Wet soil slowed movement. Stakes made mounted attacks harder. Archers threatened the approach and the flanks. The French formation became too compressed to use its numbers. The English centre held long enough for those disadvantages to accumulate.

Remember the rule. An army is not powerful because it has the most people. It is powerful when those people can act together. The French had wealth, experience, armour, horses, and a larger force. But only a fraction could fight effectively at the same time. The English used the ground to make their parts work in sequence.

There is another myth to remove. Later stories claim the French outnumbered the English by five to one or more. Exact numbers remain disputed because medieval chroniclers had reasons to magnify the enemy. Professor Anne Curry used financial records to argue for roughly twelve thousand French and between eight thousand five hundred and nine thousand English.

The battle became a story about English courage. Shakespeare gave it a famous speech more than a century and a half later. That speech shaped how generations imagined the battle, but it is not a transcript of Henry's words. The battlefield was real; the legend was built over time.

The victory did not end the Hundred Years' War. Henry returned to France, conquered much of Normandy, and secured a major diplomatic settlement. Yet English power in France did not last forever. French forces eventually recovered much of the territory. Agincourt became a symbol, not a permanent solution.

You began this story believing a French knight was defeated by the weight of his armour. But the armour was designed to move. The real trap was around him: the ground, the crowd, the fallen men, and the ranks pushing forward. He did not lose because he could not move. He lost because an army moved into a space where only a few men could fight.

At Agincourt, the strongest army did not run out of strength. It ran out of room.
